package cz.kulicka.test.repository;

import cz.kulicka.entity.Ticker;
import cz.kulicka.repository.TickerRepository;

public class TickerRepositoryTest{

}
