package cz.kulicka.util;

import cz.kulicka.CoreEngine;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateTimeUtils {

    public static Date getCurrentServerDate() {
        return new Date(new Date().getTime() - CoreEngine.DATE_DIFFERENCE_BETWEN_SERVER_AND_CLIENT_MILISECONDS);
    }

    public static Calendar getNextCandlePeriod(String candlestickPeriod) {
        Calendar roundedCalendar;

        switch (candlestickPeriod) {
            case "5m":
                roundedCalendar = roundCalendarToMinutes(5);
                break;
            case "15m":
                roundedCalendar = roundCalendarToMinutes(15);
                break;
            case "30m":
                roundedCalendar = roundCalendarToMinutes(30);
                break;
            case "1h":
                roundedCalendar = roundCalendarToMinutes(60);
                break;
            case "2h":
                roundedCalendar = roundCalendarToMinutes(120);
                break;
            case "4h":
                roundedCalendar = roundCalendarToMinutes(240);
                break;
            case "6h":
                roundedCalendar = roundCalendarToMinutes(360);
                break;
            case "8h":
                roundedCalendar = roundCalendarToMinutes(480);
                break;
            case "12h":
                roundedCalendar = roundCalendarToMinutes(720);
                break;
            case "1d":
                roundedCalendar = roundCalendarToMinutes(1440);
                break;
            default:
                throw new IllegalArgumentException("Invalid candle period!");
        }

        return roundedCalendar;
    }

    public static Calendar roundCalendarToMinutes(int minutes) {
        Calendar roundedCalendar = new GregorianCalendar();
        roundedCalendar.setTime(new Date());

        int minute = roundedCalendar.get(Calendar.MINUTE);
        minute = minute % minutes;
        if (minute != 0) {
            int minuteToAdd = minutes - minute;
            roundedCalendar.add(Calendar.MINUTE, minuteToAdd);
        } else {
            roundedCalendar.add(Calendar.MINUTE, minutes);
        }
        roundedCalendar.set(Calendar.SECOND, 0);

        return roundedCalendar;
    }


}
