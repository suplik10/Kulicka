package cz.kulicka.enums;

import javax.annotation.Nonnull;

public interface OrderEnum {
        @Nonnull
        int getCST();
}
