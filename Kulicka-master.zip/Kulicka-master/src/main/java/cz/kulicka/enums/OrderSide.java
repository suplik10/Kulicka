package cz.kulicka.enums;

/**
 * Buy/Sell order side.
 */
public enum OrderSide {
  BUY,
  SELL
}
