package cz.kulicka.constant;

public class CommonConstants {

    public static final int STOP_ACTION_RESPONSE_CODE = 429;
}
