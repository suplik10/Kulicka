package cz.kulicka.constant;

import java.util.ArrayList;
import java.util.Arrays;

public class CurrenciesConstants {

    public static final String BTC = "BTC";
    public static final String BTCUSDT = "BTCUSDT";

    public static final ArrayList<String> BLACK_LIST = new ArrayList<>(Arrays.asList("USDT"));

}
