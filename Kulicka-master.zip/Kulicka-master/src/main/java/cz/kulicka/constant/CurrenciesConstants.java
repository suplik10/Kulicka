package cz.kulicka.constant;

import java.util.ArrayList;
import java.util.Arrays;

public class CurrenciesConstants {

    public static final String BTC = "BTC";
    public static final String BTCUSDT = "BTCUSDT";

}
