package cz.kulicka.constant;

public class AppConstants {

    public static final String CURRENCY_LIST_FILE_PATH = "temp/actualCurrencies";
}
