# neverEndingProject

0 - log.info("TAKE PROFIT");

1 - log.info("PANIC SELL!!! - STOPLOSS");

2 - log.info("PANIC SELL!!! - MACD");

3 - log.info("INSTA SELL!!! - TAKE PROFIT");

4 - log.info("INSTA SELL!!! - STOPLOSS");